echo "开始 npm i"
cnpm i||npm i
echo "停止服务 "
npm run stop
echo "开启服务"
npm run start
echo "结束 npm i"